package servlets;
import java.io.*;
import java.sql.*;
import javax.servlet.*;

import config.DBConnection;
import constants.ContractRegisterConstants;
import constants.db.SigneeDBConstants;

public class ViewSigneeServlet extends GenericServlet{
	public void service(ServletRequest req,ServletResponse res) throws IOException,ServletException
	{
		PrintWriter pw = res.getWriter();
		res.setContentType("text/html");
		try {
			Connection con = DBConnection.getCon();
			PreparedStatement ps = con.prepareStatement("Select * from " + SigneeDBConstants.TABLE_SIGNEE);
			ResultSet rs = ps.executeQuery();
			RequestDispatcher rd = req.getRequestDispatcher("ViewSignee.html");
			rd.include(req, res);
			pw.println("<div class=\"tab\">View Signee</div>");
			pw.println("<div class=\"tab\">\r\n" + 
					"		<table>\r\n" + 
					"			<tr>\r\n" + 
					"				\r\n" + 
					"				<th>ID</th>\r\n" + 
					"				<th>Name</th>\r\n" + 
					"				<th>Address</th>\r\n" + 
					"				<th>Phone</th>\r\n" +
					"			</tr>");
			while(rs.next())
			{
				String SId = rs.getString(1);
				String SName = rs.getString(2);
				String SAddress = rs.getString(3);
				String SPhone = rs.getString(4);
				pw.println("<tr><td>"+SId+"</td>");
				pw.println("<td>"+SName+"</td>");
				pw.println("<td>"+SAddress+"</td>");
				pw.println("<td>"+SPhone+"</td></tr>");
			}
			pw.println("</table>\r\n" + 
					"	</div>");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
