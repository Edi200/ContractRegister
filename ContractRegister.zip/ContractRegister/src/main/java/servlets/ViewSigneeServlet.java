package servlets;
import java.io.*;
import java.sql.*;
import javax.servlet.*;

import config.DBConnection;
import constants.ContractRegisterConstants;
import constants.db.SigneeDBConstants;

public class ViewSigneeServlet extends GenericServlet{
	public void service(ServletRequest req,ServletResponse res) throws IOException,ServletException
	{
		PrintWriter pw = res.getWriter();
		res.setContentType("text/html");
		try {
			Connection con = DBConnection.getCon();
			PreparedStatement ps = con.prepareStatement("Select * from " + SigneeDBConstants.TABLE_SIGNEE);
			ResultSet rs = ps.executeQuery();
			RequestDispatcher rd = req.getRequestDispatcher("ViewSignee.html");
			rd.include(req, res);
			pw.println("<div class=\"tab\">View Signee</div>");
			pw.println("<div class=\"tab\">\r\n" + 
					"		<table>\r\n" + 
					"			<tr>\r\n" + 
					"				\r\n" + 
					"				<th>ID</th>\r\n" + 
					"				<th>Name</th>\r\n" + 
					"				<th>Address</th>\r\n" + 
					"				<th>Phone</th>\r\n" +
					"			</tr>");
			while(rs.next())
			{
				int Id = rs.getInt(1);
				String sName = rs.getString(2);
				String sAddress = rs.getString(3);
				String sPhone = rs.getString(4);
				pw.println("<tr><td>"+Id+"</td>");
				pw.println("<td>"+sName+"</td>");
				pw.println("<td>"+sAddress+"</td>");
				pw.println("<td>"+sPhone+"</td></tr>");
			}
			pw.println("</table>\r\n" + 
					"	</div>");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
