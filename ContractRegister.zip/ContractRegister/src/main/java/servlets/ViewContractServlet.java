package servlets;
import java.io.*;
import java.sql.*;
import javax.servlet.*;

import config.DBConnection;
import constants.ContractRegisterConstants;
import constants.db.ContractsDBConstants;

public class ViewContractServlet extends GenericServlet{
	public void service(ServletRequest req,ServletResponse res) throws IOException,ServletException
	{
		PrintWriter pw = res.getWriter();
		res.setContentType("text/html");
		try {
			Connection con = DBConnection.getCon();
			PreparedStatement ps = con.prepareStatement("Select * from " + ContractsDBConstants.TABLE_CONTRACT);
			ResultSet rs = ps.executeQuery();
			RequestDispatcher rd = req.getRequestDispatcher("ViewContracts.html");
			rd.include(req, res);
			pw.println("<div class=\"tab\">Contracts Available In Our Store</div>");
			pw.println("<div class=\"tab\">\r\n" + 
					"		<table>\r\n" + 
					"			<tr>\r\n" + 
					"				\r\n" + 
					"				<th>Contract ID</th>\r\n" + 
					"				<th>Contract Date</th>\r\n" + 
					"				<th>Contract Company</th>\r\n" + 
					"				<th>Description</th>\r\n" +
					                "<th>Signee ID</th>\r\n" + 
					"				<th>Signee Nam</th><br/>\r\n" + 
					"			</tr>");
			while(rs.next())
			{
				String cId = rs.getString(1);
				String cDate = rs.getString(2);
				String cCompany = rs.getString(3);
				String cDesc = rs.getString(4);
				int cSignee = rs.getInt(5);
				String cName = rs.getString(6);
				
				pw.println("<tr><td>"+cId+"</td>");
				pw.println("<td>"+cDate+"</td>");
				pw.println("<td>"+cCompany+"</td>");
				pw.println("<td>"+cDesc+"</td>");
				pw.println("<td>"+cSignee+"</td></tr>");
				pw.println("<td>"+cName+"</td>");
				
			}
			pw.println("</table>\r\n" + 
					"	</div>");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
