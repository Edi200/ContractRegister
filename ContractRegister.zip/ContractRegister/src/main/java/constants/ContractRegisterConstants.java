package constants;

public interface ContractRegisterConstants {
	public static String CONTENT_TYPE_TEXT_HTML = "text/html";
	
}
