package constants.db;

public interface SigneeDBConstants {
	
    public static String TABLE_SIGNEE = "signee";
	
	public static String COLUMN_ID = "id";
	public static String COLUMN_S_NAME = "s_name";
	public static String COLUMN_ADDRESS = "address";
	public static String COLUMN_PHONE = "phone";
}
